﻿using System;


namespace Dapper.SimpleLoad.Tests.Mocks
{
    public class MockDbQueryExecutedException: Exception
    {
    }
}
