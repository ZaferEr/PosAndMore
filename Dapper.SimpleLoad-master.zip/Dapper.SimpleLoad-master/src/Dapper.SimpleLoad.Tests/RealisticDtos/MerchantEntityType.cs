﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dapper.SimpleLoad.Tests.RealisticDtos
{
    public enum MerchantEntityType : byte
    {
        Prospect = 0,
        Customer = 1,
        Lapsed = 2
    }
}
