﻿using System;

namespace Dapper.SimpleLoad
{
    public class SimpleLoadIgnoreAttribute : Attribute
    {
    }
}
