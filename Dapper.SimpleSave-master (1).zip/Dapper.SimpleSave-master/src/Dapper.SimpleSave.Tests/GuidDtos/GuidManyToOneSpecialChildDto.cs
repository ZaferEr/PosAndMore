﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidManyToOneSpecialChild")]
    [ReferenceData(true)]
    public class GuidManyToOneSpecialChildDto : GuidBaseChildDto {
    }
}
