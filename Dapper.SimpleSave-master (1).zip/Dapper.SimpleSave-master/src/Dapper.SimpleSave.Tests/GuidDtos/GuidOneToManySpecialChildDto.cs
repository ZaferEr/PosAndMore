﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidOneToManySpecialChild")]
    [ReferenceData(true)]
    public class GuidOneToManySpecialChildDto : GuidBaseOneToManyChildDto {
    }
}
