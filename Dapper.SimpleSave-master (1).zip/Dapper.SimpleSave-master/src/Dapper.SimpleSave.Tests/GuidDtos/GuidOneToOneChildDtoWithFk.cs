﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidOneToOneChildWithFk")]
    public class GuidOneToOneChildDtoWithFk : GuidBaseOneToOneChildDtoWithFk
    {
    }
}
