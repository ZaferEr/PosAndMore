﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidManyToManySpecialChild")]
    [ReferenceData(true)]
    public class GuidManyToManySpecialChildDto : GuidBaseManyToManyChildDto {
    }
}
