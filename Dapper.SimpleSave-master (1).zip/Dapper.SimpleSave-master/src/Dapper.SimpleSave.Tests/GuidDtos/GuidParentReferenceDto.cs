﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidParentReference")]
    [ReferenceData]
    public class GuidParentReferenceDto : GuidParentDto {
    }
}
