﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidOneToOneChildNoFk")]
    public class GuidOneToOneChildDtoNoFk : GuidBaseChildDto {
    }
}
