﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidOneToManyChild")]
    public class GuidOneToManyChildDto : GuidBaseOneToManyChildDto {
    }
}
