﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidManyToOneReferenceChild")]
    [ReferenceData]
    public class GuidManyToOneReferenceChildDto : GuidBaseChildDto {
    }
}
