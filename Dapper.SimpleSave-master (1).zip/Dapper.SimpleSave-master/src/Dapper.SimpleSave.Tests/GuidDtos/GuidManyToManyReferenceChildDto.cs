﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidManyToManyReferenceChild")]
    [ReferenceData]
    public class GuidManyToManyReferenceChildDto : GuidBaseManyToManyChildDto {
    }
}
