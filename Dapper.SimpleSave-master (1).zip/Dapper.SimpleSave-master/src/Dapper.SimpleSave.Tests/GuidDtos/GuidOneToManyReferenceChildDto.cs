﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidOneToManyReferenceChild")]
    [ReferenceData]
    public class GuidOneToManyReferenceChildDto : GuidBaseOneToManyChildDto {
    }
}
