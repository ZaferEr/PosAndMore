﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidManyToManyChild")]
    public class GuidManyToManyChildDto : GuidBaseManyToManyChildDto {
    }
}
