﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidParentSpecial")]
    [ReferenceData(true)]
    public class GuidParentSpecialDto : GuidParentDto {
    }
}
