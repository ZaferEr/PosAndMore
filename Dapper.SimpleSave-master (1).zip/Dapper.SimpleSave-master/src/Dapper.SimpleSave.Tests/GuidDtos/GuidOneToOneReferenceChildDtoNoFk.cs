﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidOneToOneReferenceChildNoFk")]
    [ReferenceData]
    public class GuidOneToOneReferenceChildDtoNoFk : GuidBaseChildDto {
    }
}
