﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidManyToOneChild")]
    public class GuidManyToOneChildDto : GuidBaseChildDto {
    }
}
