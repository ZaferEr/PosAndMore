﻿namespace Dapper.SimpleSave.Tests.GuidDtos {
    [Table("dbo.GuidOneToOneReferenceChildWithFk")]
    [ReferenceData]
    public class GuidOneToOneReferenceChildDtoWithFk : GuidBaseOneToOneChildDtoWithFk
    {
    }
}
