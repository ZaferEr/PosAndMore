﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.ManyToManyReferenceChild")]
    [ReferenceData]
    public class ManyToManyReferenceChildDto : BaseManyToManyChildDto {
    }
}
