﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.OneToOneChildWithFk")]
    public class OneToOneChildDtoWithFk : BaseOneToOneChildDtoWithFk
    {
    }
}
