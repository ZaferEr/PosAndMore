﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.OneToOneChildNoFk")]
    public class OneToOneChildDtoNoFk : BaseChildDto {
    }
}
