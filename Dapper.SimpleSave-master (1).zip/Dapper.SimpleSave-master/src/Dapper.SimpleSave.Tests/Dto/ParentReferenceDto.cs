﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.ParentReference")]
    [ReferenceData]
    public class ParentReferenceDto : ParentDto {
    }
}
