﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.OneToManySpecialChild")]
    [ReferenceData(true)]
    public class OneToManySpecialChildDto : BaseOneToManyChildDto {
    }
}
