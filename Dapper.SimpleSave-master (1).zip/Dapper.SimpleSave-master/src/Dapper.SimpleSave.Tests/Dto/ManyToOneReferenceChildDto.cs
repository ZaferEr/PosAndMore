﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.ManyToOneReferenceChild")]
    [ReferenceData]
    public class ManyToOneReferenceChildDto : BaseChildDto {
    }
}
