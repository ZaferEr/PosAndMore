﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.ManyToManyChild")]
    public class ManyToManyChildDto : BaseManyToManyChildDto {
    }
}
