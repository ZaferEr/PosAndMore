﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.ManyToOneChild")]
    public class ManyToOneChildDto : BaseChildDto {
    }
}
