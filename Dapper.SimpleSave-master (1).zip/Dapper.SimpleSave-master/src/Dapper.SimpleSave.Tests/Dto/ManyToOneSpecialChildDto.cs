﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.ManyToOneSpecialChild")]
    [ReferenceData(true)]
    public class ManyToOneSpecialChildDto : BaseChildDto {
    }
}
