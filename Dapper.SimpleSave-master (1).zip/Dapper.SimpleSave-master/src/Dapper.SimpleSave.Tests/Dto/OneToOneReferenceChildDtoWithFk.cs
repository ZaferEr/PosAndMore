﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.OneToOneReferenceChildWithFk")]
    [ReferenceData]
    public class OneToOneReferenceChildDtoWithFk : BaseOneToOneChildDtoWithFk
    {
    }
}
