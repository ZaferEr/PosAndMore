﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.OneToManyChild")]
    public class OneToManyChildDto : BaseOneToManyChildDto {
    }
}
