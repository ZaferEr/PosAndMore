﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.OneToOneReferenceChildNoFk")]
    [ReferenceData]
    public class OneToOneReferenceChildDtoNoFk : BaseChildDto {
    }
}
