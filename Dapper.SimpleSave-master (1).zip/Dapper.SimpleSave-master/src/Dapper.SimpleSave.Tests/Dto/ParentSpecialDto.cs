﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.ParentSpecial")]
    [ReferenceData(true)]
    public class ParentSpecialDto : ParentDto {
    }
}
