﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.OneToManyReferenceChild")]
    [ReferenceData]
    public class OneToManyReferenceChildDto : BaseOneToManyChildDto {
    }
}
