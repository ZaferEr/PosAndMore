﻿namespace Dapper.SimpleSave.Tests.Dto {
    [Table("dbo.ManyToManySpecialChild")]
    [ReferenceData(true)]
    public class ManyToManySpecialChildDto : BaseManyToManyChildDto {
    }
}
