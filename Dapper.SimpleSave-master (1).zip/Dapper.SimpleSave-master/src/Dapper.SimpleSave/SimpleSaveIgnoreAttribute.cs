﻿using System;

namespace Dapper.SimpleSave
{
    public class SimpleSaveIgnoreAttribute : Attribute
    {
    }
}
