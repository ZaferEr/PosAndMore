﻿namespace Dapper.SimpleSave.Impl
{
    public class Ancestor
    {
        public object OldObject { get; set; }
        public object NewObject { get; set; }
    }
}
