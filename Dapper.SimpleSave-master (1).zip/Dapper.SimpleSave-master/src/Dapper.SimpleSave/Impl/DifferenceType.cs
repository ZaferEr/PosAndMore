﻿namespace Dapper.SimpleSave.Impl
{
    public enum DifferenceType
    {
        Insertion,
        Deletion,
        Update
    }
}
