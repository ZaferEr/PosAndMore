﻿namespace Dapper.SimpleSave.Impl
{
    public abstract class BaseInsertDeleteOperation : BaseOperation
    {
    }
}
