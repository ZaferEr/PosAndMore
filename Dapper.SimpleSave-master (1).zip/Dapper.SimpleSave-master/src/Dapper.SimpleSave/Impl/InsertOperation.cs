﻿namespace Dapper.SimpleSave.Impl
{
    public class InsertOperation : BaseInsertDeleteOperation {}
}
