﻿namespace Dapper.SimpleSave.Impl {
    public class DeleteOperation : BaseInsertDeleteOperation
    {
    }
}
