﻿using System;

namespace Dapper.SimpleSave
{
    public class DoNotAutoWireExplicitTransitiveBackReferenceAttribute : Attribute
    {
    }
}
