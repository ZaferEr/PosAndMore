﻿using System;

namespace Dapper.SimpleSave
{
    public class OneToManyAttribute : Attribute
    {
    }
}
