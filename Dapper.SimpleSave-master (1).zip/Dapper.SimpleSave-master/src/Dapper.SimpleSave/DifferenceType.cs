﻿namespace Dapper.SimpleSave
{
    public enum DifferenceType
    {
        Insertion,
        Deletion,
        Update
    }
}
